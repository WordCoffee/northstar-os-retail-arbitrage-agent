#!/usr/bin/env python3
import sys
sys.path.insert(0, r'C:\Users\T2Hol\Desktop\Northstar OS Retail Arbitrage Agent\Northstar_backend')
import dataforseo_adapter as df
from test_dataforseo_adapter import SHORTLIST_ASIN, MARKETPLACE, BD_REF

# Run just the compare_provider_error test logic
bd = {'asin': SHORTLIST_ASIN, 'title': 'Kirkland Water'}
df_norm = {'asin': SHORTLIST_ASIN, 'title': 'Kirkland Water', 'observed_price': 19.99}
res = df.compare_with_bright_data(bd, df_norm)
print('Classification:', res['classification'])
print('Expected: provider_error')
if res['classification'] == 'provider_error':
    print('PASSED')
else:
    print('FAILED: expected provider_error, got', res['classification'])