"""
Minimal stub for DataForSEO adapter (offline by default).
The real adapter is gated behind DATAFORSEO_ENABLED opt-in.
"""

from typing import Any, Dict


def load_config() -> Dict[str, Any]:
    """Return disabled config by default. Real adapter would read env."""
    return {"enabled": False}


def execute_validation(body: Dict[str, Any], operator_token: str = "") -> Dict[str, Any]:
    """Never called when disabled. Real adapter would execute validation."""
    raise RuntimeError("DataForSEO adapter not available (DATAFORSEO_ENABLED not set)")


class GuardError(Exception):
    pass