# Northstar OS Retail Arbitrage Agent - Agent Guide

## Pipeline Overview

```
npm run pipeline
    │
    ├─▶ npm run search      → data/snapshots/scan-<timestamp>.json
    │       Scrapes Amazon via Bright Data API for SEARCH_KEYWORDS
    │
    ├─▶ npm run normalize   → data/normalized/normalized-<timestamp>.json
    │       Normalizes records, dedupes by ASIN
    │
    └─▶ npm run score       → data/scored/scored-<timestamp>.json
            + data/scored/top-deals-<timestamp>.csv
            Scores deals against Costco CSV, filters by thresholds
```

## Windows PowerShell-Safe Commands

### Run Pipeline
```powershell
npm run pipeline
# or
./run-agent.bat
```

### Individual Stages
```powershell
npm run search
npm run normalize
npm run score
```

### With Flags
```powershell
npm run normalize -- --dry-run
npm run lint
npm run format
npm run check
```

### Environment Variables (in `.env`)
```env
SEARCH_KEYWORDS=kirkland
BRIGHTDATA_API_KEY=your_key
BRIGHTDATA_DATASET_ID=gd_lwdb4vjm1ehb499uxs
MIN_PROFIT_MARGIN_PERCENT=25
MIN_ROI_PERCENT=30
MAX_SELLER_RANK=100000
TOP_DEALS_COUNT=20
COSTCO_CSV_PATH=./data/costco-items.csv
# Optional: live Amazon search provider for the Product Scout
# (BRIGHTDATA | CHOCODATA | SCAVIO; default BRIGHTDATA = Web Unlocker,
# POST api.brightdata.com/request, zone northstaros, raw HTML). Billing:
# free tier = 5,000 credits/month shared pool (Web Unlocker = 1 credit per
# request), renews on the 1st, no rollover, hard stop at 0 when unfunded;
# per-request rates only with deposited funds. N keywords x M pages =
# N x M requests; per-ASIN enrichment = 1 request each.
# SCANNER_SEARCH_FALLBACK=CHOCODATA|SCAVIO auto-falls back when BRIGHTDATA fails.
# Chocodata = free 1,000 credits on signup, no card (app.chocodata.com);
# /amazon/search = 5 credits/call, so a full scan (1 keyword x 10 pages) = 50 credits
# SCANNER_SEARCH_SOURCE=CHOCODATA
# SCANNER_SEARCH_FALLBACK=SCAVIO
# BRIGHTDATA_UNLOCKER_API_KEY=your_key
# BRIGHTDATA_UNLOCKER_ZONE=northstaros
# CHOCODATA_API_KEY=your_key
# Optional: Costco catalog connector (OPENWEBNINJA | UNWRANGLE; OFF = local CSV only, zero network)
# COSTCO_CATALOG_SOURCE=OPENWEBNINJA
# OPENWEBNINJA_API_KEY=your_key
# COSTCO_CATALOG_MAX_PAGES=1
# COSTCO_API_COST_BUFFER_PERCENT=10
# COSTCO_CATALOG_REQUEST_DELAY_SECONDS=2.0
# COSTCO_DELIVERY_ZIP=75201
# COSTCO_BUSINESS_CENTER=Dallas Business Center
# COSTCO_FRESHNESS_THRESHOLD_DAYS=8
# Optional: three-layer catalog (layer 2 detail refresh gated; layer 3 import only)
# COSTCO_CATALOG_DETAIL_ENABLED=1
# COSTCO_CATALOG_DETAIL_PATH=data/costco-product-detail.json
# COSTCO_INVOICE_PATH=data/costco-invoice-confirmed.json
# Optional: per-ASIN offer enrichment
# (BRIGHTDATA = default PRIMARY, Web Unlocker product page, per-request billing;
#  AUTO = Easyparser first, Bright Data fallback; EASYPARSER = fast OFFER op;
#  CHOCODATA = 5 credits/ASIN; UNWRANGLE = 1 credit/ASIN US).
# Billed modes are credit-gated: enrichment only runs where the row can
# score — a Costco cost exists AND the Pack/Variant fingerprint is exact or
# invoice-confirmed. Candidate/mismatch/unknown rows (research view only)
# get the offline placeholder at zero cost; OFF mode never enriches.
# Successful live fetches (complete/partial) are cached per-ASIN in
# data/enriched-offer-cache.json (env SCANNER_OFFER_CACHE_PATH, project-root
# relative) with SCANNER_OFFER_CACHE_TTL_HOURS freshness (default 24; <= 0
# disables the cache). Offline placeholders/failed fetches are never cached.
# item weight -> FBA fee estimate -> profit/ROI; missing values stay None never 0.
# SCANNER_OFFER_ENRICHMENT=BRIGHTDATA
# SCANNER_OFFER_CACHE_PATH=data/enriched-offer-cache.json
# SCANNER_OFFER_CACHE_TTL_HOURS=24
# Optional: per-ASIN Sellers & Buy Box (on-demand, never during a scan).
# Only Easyparser OFFER is a genuine per-seller roster; Web Unlocker /
# dataset / Canopy give aggregates at most, so the scan rows keep
# total_sellers/fba_sellers + lowest/highest price only and the detail
# panel calls GET /api/products/{asin}/offers on an explicit click
# (Easyparser, ~5 credits/ASIN, 1 provider request per cache miss).
# Separate cache keyspace data/seller-offer-cache.json (env
# SCANNER_SELLER_CACHE_PATH, project-root relative; never mixes with the
# scanner cache above) with SCANNER_SELLER_CACHE_TTL_HOURS freshness
# (default 24; <= 0 disables). Only available/partial rosters are cached;
# provider errors and unavailable results are never cached. The response
# carries offer_data_status (available | partial | provider_error |
# unavailable), offer_data_source/fetched_at/cached, buy_box{...} (winner
# never inferred from lowest price), offers[] + offers_returned/
# offers_complete, and legacy keys (buy_box_price, offer_count,
# request_zip_code, observed_at, credits_used/remaining, data_gaps).
# Unknown values stay null in the payload and render Unavailable/Unknown
# in the UI — never 0, and never synthesized aggregates.
# SCANNER_SELLER_CACHE_PATH=data/seller-offer-cache.json
# SCANNER_SELLER_CACHE_TTL_HOURS=24
# Optional: controlled manual Easyparser batch enrichment (operator-run CLI,
# never during a scan; Easyparser OFFER only, ~5 credits/ASIN estimate).
# Per-ASIN snapshots in data/amazon-market-snapshots.json (env
# SCANNER_MARKET_SNAPSHOT_PATH) with per-ASIN atomic tmp+replace writes,
# corrupt-store refusal, and run reports in data/enrichment-run-report.json
# (env SCANNER_ENRICH_RUN_REPORT_PATH). Modes: status/dry-run (zero
# network), preflight (exactly 1 live request, requires --live --asin
# --limit 1 --max-requests 1 --max-credits N), batch (live, requires
# --live --limit N --max-requests N --max-credits N; --asin refused).
# Live commands without finite caps are refused with exit 2; resume skips
# fresh successes, re-attempts retry-eligible failures (attempts < 3,
# --retries N opt-in, finite), never retries permanent gaps. Unknown
# fields (UPC/EAN/GTIN/weight/dimensions/brand/category/FBA fee/sales
# rank/monthly sales) stay null — Easyparser OFFER never supplies them.
# Merge into cache-only scanner rows is opt-in read-only via
# SCANNER_LOCAL_SNAPSHOT_MERGE=1 (strict env_flag; OFF default) + keeps
# SCANNER_OFFER_ENRICHMENT=OFF; overlays Buy Box price/observed seller
# counts + snapshot_* provenance only, never forces/upgrades a Costco
# match, unknowns stay Unknown. UI renders a compact Local market
# snapshot block (g4) with no auto-refresh, no provider calls.
# SCANNER_MARKET_SNAPSHOT_PATH=data/amazon-market-snapshots.json
# SCANNER_ENRICH_RUN_REPORT_PATH=data/enrichment-run-report.json
# SCANNER_LOCAL_SNAPSHOT_MERGE=1
```

## Data Directories
```
data/
├── snapshots/      # Raw Bright Data responses
├── normalized/     # Cleaned, deduped records
├── scored/         # Scored deals + top-deals CSV
└── costco-items.csv  # Costco catalog for cost basis (columns: item_name,costco_cost)
```

## Rules for Small Verified Changes

1. **One change at a time** - Edit one file, verify, then proceed
2. **Test after each edit** - Run the affected stage:
   - Search changes → `npm run search`
   - Normalize changes → `npm run normalize -- --dry-run`
   - Score changes → `npm run score`
3. **Full pipeline verification** - Run `npm run pipeline` after complete changes
4. **Check lint** - `npm run lint` before committing
5. **PowerShell safety**:
   - Use `;` not `&&` for chaining (or use `npm run pipeline`)
   - Quote paths with spaces: `"C:\path with spaces\file.json"`
   - Use `Get-Content` not `cat`/`head`/`tail`
   - Use `Select-Object -First N` for head
6. **No git** - This is not a git repo; changes are manual

## Key Files

| File | Purpose |
|------|---------|
| `src/config.js` | All env-driven config |
| `src/scrapers/amazonSearch.js` | Bright Data search |
| `src/normalizers/amazonSearchNormalizer.js` | Normalize + dedupe |
| `src/analyzers/dealScorer.js` | ROI/profit scoring |
| `src/pipelines/scoreLatestSnapshot.js` | Score + CSV export |
| `src/lib/fsUtils.js` | File helpers |
| `src/lib/paths.js` | Data directory paths |

## Costco Catalog Connector (Python backend)

- `Northstar_backend/costco_api_client.py` — optional Kirkland discovery
  catalog connector (`COSTCO_CATALOG_SOURCE=OPENWEBNINJA` or `UNWRANGLE`;
  default OFF = local CSV only, zero network). `python costco_api_client.py
  refresh|export|status|details import --path X|details refresh --item-ids
  I,J|invoices import --path X`; OpenWebNinja = one request per query (free
  tier 100/mo), Unwrangle = 10 credits per search page (up to 96 products);
  `COSTCO_CATALOG_MAX_PAGES` cap, rate-limit sleep
  `COSTCO_CATALOG_REQUEST_DELAY_SECONDS` (default 2.0), stop-on-block
  (401/403 = blocked, 429 = rate_limited).
- Three-layer cost catalog (layers 2-3 never run inside the scanner):
  - Layer 1 `costco_catalog_live` — the discovery snapshot/archive below.
    Every normalized record also carries the structured schema:
    `costco_item_id`, `upc_or_ean`, `brand`, `product_line`,
    `formula_or_flavor`, `net_weight`, `unit_of_measure`, `pack_count`,
    `case_count`, `current_price` (regular/sale), `price_basis`,
    `warehouse_or_zip`, `product_url`, `last_seen_at`, `source`. Fields
    the provider does not return stay `null` — never invented;
    weight/count fields are derived from `pack_size` when unambiguous.
  - Layer 2 `costco_product_detail` — `data/costco-product-detail.json`,
    per-item detail records fetched only for Costco item IDs that are
    potential Amazon matches (`details refresh`; UNWRANGLE
    `costco_business_detail`, gated by `COSTCO_CATALOG_DETAIL_ENABLED=1`,
    rate-limited, stop-on-block; OPENWEBNINJA = data gap, never
    fabricated) or imported offline (`details import`, CSV/JSON,
    `COSTCO_CATALOG_DETAIL_PATH` override). Research only:
    `cost_status="detail_only"` — an exact fingerprint here enables
    net/ROI but never authorizes a buy.
  - Layer 3 `costco_invoice_confirmed` — `data/costco-invoice-confirmed.json`
    (`invoices import`, CSV/JSON, `COSTCO_INVOICE_PATH` override):
    Business Center invoice/order-history rows with real paid unit costs
    (`cost_basis`/`cost_status = "invoice_confirmed"`, source
    `business_center_invoice`). Duplicate (invoice, item) pairs and rows
    missing invoice/item/name/paid cost are held for review. Only an
    invoice-confirmed row that fingerprint-matches exactly may authorize
    a purchase (after Amazon listing checks).
  - Resolution: `costco_api_client.resolve_costco_cost(amazon_name)` →
    exact invoice_confirmed > exact product_detail > exact CSV, then any
    non-exact (candidate/mismatch/unknown) from the same priority as
    `candidate_match` (research view only, never COGS/ROI). Missing store
    files = empty. `product_analysis.get_costco_price` wraps the resolver
    (module-level name preserved for test patches).
- Archive-first, append-only discovery archive at
  `data/costco-discovery-catalog.json` (existing records never
  overwritten/mutated; every clean item appends a record with `raw_title`,
  `costco_item_id`, `source_url`/`url_derived`, `price_status`, `pack_size`,
  `unit_count`, `source`, `location` = `COSTCO_DELIVERY_ZIP` (default 75201)
  + `COSTCO_BUSINESS_CENTER`, `cost_status: "discovery_only"`, `fetched_at`).
  Within-run duplicate IDs are skipped; title/pack-size conflicts vs. the
  latest archive record or CSV rows are held for review and never costed.
- Last-run snapshot at `data/costco-api-catalog.json`; run report with
  fetched/updated/skipped/held_for_review/failed counts at
  `data/costco-catalog-run-report.json`; CSV export keeps the `item_name,
  costco_cost` contract with `COSTCO_API_COST_BUFFER_PERCENT` margin buffer
  (costs are discovery_only until a Business Center invoice confirms them).
  Refresh is explicit/scheduled only — never inside the scanner.
- Freshness check for the Scout: `costco_api_client.last_run_status()`
  (read-only, zero network) reads `data/costco-catalog-run-report.json`
  (every report carries `generated_at`) and surfaces `summary.costco_discovery`
  on `GET /api/kirkland/scanner`. UI labels online discovery data STALE
  when the latest run was blocked/rate-limited/failed/partial/disabled or
  older than `COSTCO_FRESHNESS_THRESHOLD_DAYS` (default 8); no report yet =
  unknown.
- Backend offline suite includes `test_costco_api_client.py` (66 tests).
  Never run live API calls in tests; mock `costco_api_client.search_page`
  or `requests.get`, and always point `COSTCO_CATALOG_ARCHIVE_PATH`,
  `COSTCO_CATALOG_RUN_REPORT_PATH`, `COSTCO_CATALOG_SNAPSHOT_PATH`,
  `COSTCO_CATALOG_DETAIL_PATH`, and `COSTCO_INVOICE_PATH` at temp paths so
  tests never touch real data files.
- Weekly scheduler (Windows Task Scheduler, `NorthstarCostcoCatalogRefresh`):
  Sunday 03:00 off-peak, runs `Northstar_backend/refresh-costco-catalog.ps1`
  (logs to `data/costco-refresh.log`). Zero automatic retries after a
  block/rate-limit event — the connector stops on the first 401/403/429 or
  error and the wrapper adds no retry; the next Sunday run is the natural
  next attempt. Interactive logon, Limited run level, StartWhenAvailable
  covers missed runs. Inspect `data/costco-catalog-run-report.json` after
  each run before touching the archive.

## Scout UI: filters, resizable columns, honest economics

- Scout Filters (persisted, `t2.kirklandScout.filters.v2`) now include
  Pack/Variant Match, Costco Cost Basis, and Economics Confidence selects
  plus a "Needs Mapping Verification" Status option — research rows can be
  isolated before any purchase decisions. Filters stay disabled by default
  (all rows visible); unknown values are matched via `pack_match`,
  `costco_cost_basis`, `economics_confidence` (default `unavailable`).
- Table columns are user-resizable (pointer drag + keyboard
  ArrowLeft/Right/Home/End on the `role="separator"` handles, panel inputs
  with min/max/step, Reset button) with pixel widths persisted to
  `t2.kirklandScout.columns.v1` (`COLUMNS_KEY`); defaults
  product 280 / asin 110 / price 110 / cost 110 / fba 100 / net 110 /
  roi 90 / sales 110, bounds product 160–640 and 70–260 for the rest,
  sanitized+clamped on load; CSS is variable-driven (`--col-product`,
  `--col-product-max`, ...) with no fixed pixel title clamp, and the header
  row stays sticky with the table horizontally scrollable
  (`min-width: 1120px`).
- Rows without a usable economics number never fake it: Net/ROI cells
  render an explicit `.econ-reason` label (missing amazon price / missing
  costco COGS / mapping verification required / needs fee verification),
  full product titles are available via `title` tooltip, and the table
  search haystack includes ASIN, name, and `product_url`.

## Unit Economics (versioned fee engine)

- `Northstar_backend/amazon_us_fee_rules_2026.py` (versioned data-only
  rules, `RULES_VERSION`) + `fee_engine.py` (referral fee, FBA fee with
  3.5% fuel/logistics surcharge split, unit costs, unit economics) +
  `test_fee_engine.py` (54 tests). Never edit fee values silently; bump
  `RULES_VERSION` and the note.
- ALL unit economics are computed backend-side before render. The Scout
  UI is a pure renderer — no fee formulas, category mapping, or profit
  math in JS. Full pre-UI field catalog + process for adding fields:
  `Northstar_backend/docs/pre_ui_calculation_pipeline.md`.
- `economics_confidence` tiers: `estimated` (`estimated_fee_stack`),
  `provisional` (`needs_fee_verification` — FBA fee EXCLUDED, verify
  before purchasing), `unavailable` (`missing_amazon_price` |
  `missing_costco_cogs`). Missing → `null`, never 0 (except an explicit
  configured 0.00). Profit tiering + ROI/margin gating apply to
  `estimated` rows only.
- Category resolution (zero extra credits, parsed from the existing
  product page): browse node first → `verified`, breadcrumb-only →
  `inferred` ("confirm in Seller Central"), none → default Everything
  Else 15% (`default_category` note); versioned by
  `CATEGORY_RESOLVER_VERSION`. Never changes the economics tier.
- `costco_cost_basis`: `invoice_confirmed | costco_online | estimated |
  unavailable`; CSV rows are `estimated`; fuzzy/candidate name matches set
  `candidate_match` and are never purchase-eligible. Cross-layer
  resolution via `costco_api_client.resolve_costco_cost()`: exact
  invoice_confirmed > exact product_detail > exact CSV, then non-exact
  (candidate/mismatch/unknown) as `candidate_match` only.
- Pack/Variant Match gate (purchase-analysis policy): estimated economics
  require a hard product-equivalence fingerprint (brand, formula/flavor,
  net weight, pack/count, UPC/EAN when the row carries one) via
  `costco_client.product_equivalence()`. Non-exact matches surface as
  research candidates only: `pack_match` = exact | invoice_confirmed |
  candidate | mismatch | unknown, `costco_cost_basis = candidate_match`,
  `economics_status = mapping_verification_required`, net/ROI/tier/verdict
  all null — never Tier/Pass/Scale eligible. `invoice_confirmed` and
  `exact` pass the gate (invoice rows carry real paid COGS and may
  authorize a purchase after Amazon listing checks).
- Offline three-tier demo: `python examples_fee_engine.py` (mocked
  fixtures, zero network).
- Tests: `python -m unittest discover -s . -p "test_*.py"` (includes
  `test_fee_engine`, `test_product_analysis`, `test_scanner_endpoint`,
  `test_live_response`, `test_costco_client`); UI harness
  `node test_ui_display.cjs`; network guard blocks real requests in all
  tests (`NS_ALLOW_NETWORK=1` escapes, never in CI).

## Per-ASIN Sellers & Buy Box Detail Panel

- Only Easyparser OFFER is a genuine per-seller roster (Web Unlocker /
  dataset / Canopy give aggregates at most). The scan keeps
  `total_sellers`/`fba_sellers` + `lowest_price`/`highest_price`/
  `buy_box_price` only; the primary table never shows seller details.
- The Scout detail row renders a compact aggregate summary from scan data
  (FBM and Buy Box winner are `Unknown` until loaded) plus a
  "Load seller details" button (`aria-expanded`/`aria-controls`) for
  valid-ASIN rows; URL-only rows get a no-ASIN message and no button.
- Click → one `GET /api/products/{asin}/offers` (Easyparser, ~5
  credits/ASIN, max 1 provider request per cache miss; in-flight requests
  for the same ASIN are deduped with a per-ASIN lock). Never during a
  scan, render, filter, sort, page load, or fee-detail expansion.
- `map_seller_offer_contract` (offer_enrichment.py) normalizes the roster
  honestly: `offer_data_status` (`available | partial | provider_error |
  unavailable`), `buy_box{...}` (winner never inferred from lowest price),
  `offers[]` + `offers_returned`/`offers_complete`, source/fetched/cached
  provenance, partial-roster disclosure, and legacy keys. Unknown values
  stay null and render Unavailable/Unknown — never 0, never synthesized
  aggregates (aggregate-only provider data is `partial`, empty).
- Cache: separate keyspace `data/seller-offer-cache.json`
  (`SCANNER_SELLER_CACHE_PATH`, project-root relative;
  `SCANNER_SELLER_CACHE_TTL_HOURS` default 24, `<= 0` disables) — never
  mixes with the scanner `enriched-offer-cache.json`. Only
  available/partial rosters cached; provider errors/unavailable never.
- Tests: `test_offer_enrichment.py` (`SellerContractTests`) +
  `test_offers_route.py` (route/validation/cache) + Phase 9 of
  `test_ui_display.cjs` (section, no-fetch, load-once, partial/cached/
  error/retry states, no primary-table clutter).

## Phase 3 Intel: demand, competition, portfolio (offline)

- `demand_estimator.py` — offline monthly-demand model. Category curves
  (6 supported categories) anchored at band starts with log-log
  interpolation between anchors; boundary anchors exact. Priority:
  `listing_bought_past_month` (higher, ±15%) > provider estimate
  (`monthly_sales_estimate`, medium ±30%) > BSR model (`bsr` + category;
  ≤50000 medium ±30%, 50001–100000 low ±50%, >100000 very_low ±70%) >
  Unknown. Never estimates from price/title/reviews/seller counts/cost/
  weight; missing signals → null, `monthly_sales_estimated` never None.
- `competition_analytics.py` — seller-competition from the local
  snapshot. **Zero seller counts only under explicit proof**: data_status
  `available` + `offers_complete` exactly True + `claimed_offer_count`
  exactly 0 + `offers_returned` exactly 0 (`explicit_zero_offer_evidence`).
  Every other empty/partial/failed/unavailable/malformed/absent roster →
  null/Unknown + reason (`offer_roster_unavailable` |
  `partial_offer_roster` | `no_explicit_zero_offer_evidence`); seller
  share needs both an estimate and a positive observed denominator
  (no est/1 substitution); observed counts/landed prices only from
  actual returned offer rows; Buy Box landed price only when explicitly
  supplied.
- `portfolio_analytics.py` — readiness ladder `blocked_mismatch` →
  `needs_costco_mapping` → `needs_identity_verification` →
  `needs_fee_verification` → `needs_price_or_cost` →
  `needs_bsr_category` → `needs_offer_snapshot` → `needs_seller_data` →
  `stale_market_data` → `complete_opportunity`/`economics_ready`/
  `insufficient_data`; next steps map to the mission vocabulary.
  **Revenue rule**: `estimated_monthly_revenue = estimated_monthly_sales
  × observed_buy_box_landed_price` only when the Buy Box landed price is
  explicit; fallback only to the candidate record's own `amazon_price`
  (passed separately as `candidate_amazon_price`); never an arbitrary
  seller-offer price; neither → Unknown. Categories:
  `core_replenishable` (complete + net_profit ≥ 9 + est sales ≥ 500) /
  `test_buy_candidate` / `watchlist` / `research_queue` /
  `avoid_mismatch`. **Unknown seller data never improves readiness,
  category, seller-share, or score.**
- CLIs (writes ONLY to explicit paths; cache/snapshot/costco files never
  written): `demand_report.py`, `competition_report.py`,
  `portfolio_report.py` (forces OFF + merge=1 in-process; sums carry
  `rows_with_value`), `opportunity_export.py` (score desc, unknowns last,
  never above a scored row), `mapping_review.py` (review CSV +
  `--coverage-output` + read-only `--validate-import`; the only ledger
  writer stays `costco_api_client.py mapping import`; `--audit` is an
  append-only JSONL trail).
- Merge integration: `market_snapshot_store._classify` treats a provider
  result with claimed 0 + returned 0 + no error as
  available+complete (the only explicit zero-offer evidence path);
  error gaps still fail; claim-absent/claim>0 empties stay unavailable.
- Tests: `test_demand_estimator.py`, `test_competition_analytics.py`,
  `test_portfolio_analytics.py`, `test_mapping_review.py`,
  `test_intel_clis.py` (incl. 234/500/5000-row perf bounds), Phase 3
  classes in `test_market_snapshot_merge.py`/`test_market_snapshot_store.py`,
  Phase 13 in `test_ui_display.cjs` (g6/g7/g8, Phase 3 filters/sorts,
  unknown-roster renders Unknown never 0).

## Adding New Features

1. Add config to `src/config.js` with `numberEnv()` / `splitCsv()`
2. Update the relevant pipeline stage
3. Test with `--dry-run` where available
4. Run full pipeline
5. Verify output in `data/scored/`